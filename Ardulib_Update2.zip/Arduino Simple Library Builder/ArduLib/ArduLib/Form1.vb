﻿Public Class Form1
    '  Asemani Personal Laboratory
    ' Post.asemani@gmail.com

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        TextBox1.Text = Replace(TextBox1.Text, Label3.Text, TextBox4.Text)
        TextBox2.Text = Replace(TextBox2.Text, Label3.Text, TextBox4.Text)
        TextBox3.Text = Replace(TextBox3.Text, Label3.Text, TextBox4.Text)
        TextBox5.Text = Replace(TextBox5.Text, Label3.Text, TextBox4.Text)
        Label3.Text = TextBox4.Text
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim msg As String
        msg = MsgBox("are you sure?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "new library?")
        If msg = vbYes Then
            TextBox1.Text = txt_header_temp.Text
            TextBox2.Text = txt_source_temp.Text
            TextBox3.Text = txt_key_temp.Text
            TextBox5.Text = txt_exam_temp.Text
            TextBox6.Text = "NewExample"
            TextBox4.Text = "New"
            Label3.Text = "New"
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        
        SaveFileDialog1.Title = "Save header file to:"
        SaveFileDialog1.FileName = TextBox4.Text
        SaveFileDialog1.Filter = "Arduino Library Header file (*.h)|*.h|All files (*.*)|*.*"
        SaveFileDialog1.ShowDialog()
        lbl_header_file.Text = SaveFileDialog1.FileName
        If lbl_header_file.Text = "" Then Exit Sub

        System.IO.File.WriteAllText(lbl_header_file.Text, TextBox1.Text)
        MessageBox.Show("Header file saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)


    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        
        SaveFileDialog1.Title = "Save source file to:"
        SaveFileDialog1.FileName = TextBox4.Text
        SaveFileDialog1.Filter = "Arduino Library Source file (*.cpp)|*.cpp|All files (*.*)|*.*"
        SaveFileDialog1.ShowDialog()
        lbl_source_file.Text = SaveFileDialog1.FileName
        If lbl_source_file.Text = "" Then Exit Sub
        System.IO.File.WriteAllText(lbl_source_file.Text, TextBox2.Text)
        MessageBox.Show("Source file saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        
        SaveFileDialog1.Title = "Save keyword file to:"
        SaveFileDialog1.FileName = "keywords"
        SaveFileDialog1.Filter = "Arduino Keywords Source file (*.txt)|*.txt|All files (*.*)|*.*"
        SaveFileDialog1.ShowDialog()
        lbl_keywoeds_file.Text = SaveFileDialog1.FileName
        If lbl_keywoeds_file.Text = "" Then Exit Sub
        
        System.IO.File.WriteAllText(lbl_keywoeds_file.Text, TextBox3.Text)
        MessageBox.Show("Keywords file saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        SaveFileDialog1.Title = "Save source file to:"
        SaveFileDialog1.FileName = TextBox6.Text
        SaveFileDialog1.Filter = "Arduino Source Code file (*.ino)|*.ino|All files (*.*)|*.*"
        SaveFileDialog1.ShowDialog()
        lbl_example_file.Text = SaveFileDialog1.FileName
        If lbl_example_file.Text = "" Then Exit Sub

        System.IO.File.WriteAllText(lbl_example_file.Text, TextBox5.Text)

        MessageBox.Show("Example file saved successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'On Error Resume Next
        Dim dirpath As String


        FolderBrowserDialog1.ShowDialog()
        dirpath = FolderBrowserDialog1.SelectedPath
        If System.IO.Directory.Exists(dirpath + "\" + TextBox4.Text) = True Then
            Dim t As String
            t = MsgBox(dirpath + "\" + TextBox4.Text + vbCrLf + "do you want to replace it?", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "same detected!")
            If t = vbOK Then
                System.IO.Directory.Delete(dirpath + "\" + TextBox4.Text, True)
            Else
                Exit Sub
            End If
        End If
            If dirpath <> "" Then
                MkDir(dirpath + "\" + TextBox4.Text)

                'header
                System.IO.File.WriteAllText(dirpath + "\" + TextBox4.Text + "\" + TextBox4.Text + ".h", TextBox1.Text)

                'source
                System.IO.File.WriteAllText(dirpath + "\" + TextBox4.Text + "\" + TextBox4.Text + ".cpp", TextBox2.Text)
                'keywords
                System.IO.File.WriteAllText(dirpath + "\" + TextBox4.Text + "\" + "keywords.txt", TextBox3.Text)
                'example

                MkDir(dirpath + "\" + TextBox4.Text + "\examples")
                MkDir(dirpath + "\" + TextBox4.Text + "\examples\" + TextBox6.Text)
                System.IO.File.WriteAllText(dirpath + "\" + TextBox4.Text + "\examples\" + TextBox6.Text + "\" + TextBox6.Text + ".ino", TextBox5.Text)

                MessageBox.Show("Library made successfuly!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
    End Sub

    Private Sub fixer(ByVal pat As String)
        Shell(Application.StartupPath + "\fixer.exe " + pat, vbNormalFocus)
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        End
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call load_inner_ketwords()
    End Sub

    Private Sub load_inner_ketwords()
        On Error Resume Next
        Dim tmp As Object
        Dim pt As String
        pt = Replace(Application.StartupPath + "\inner_keywords.apl", "\\", "\")
        FileOpen(1, pt, OpenMode.Input)
        While Not EOF(1)
            Input(1, tmp)
            ListBox1.Items.Add(tmp)
        End While
        FileClose(1)

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        On Error Resume Next
        Dim header_path As String

        OpenFileDialog1.Title = "Select a Header file:"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Arduino Library Header files (*.h)|*.h|All files (*.*)|*.*"
        OpenFileDialog1.ShowDialog()
        header_path = OpenFileDialog1.FileName
        TextBox4.Text = Replace(OpenFileDialog1.SafeFileName, ".h", "")

        TextBox1.Text = System.IO.File.ReadAllText(header_path)
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        On Error Resume Next
        Dim source_path As String
       
        OpenFileDialog1.Title = "Select a Source file:"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Arduino Library Source files (*.cpp)|*.cpp|All files (*.*)|*.*"
        OpenFileDialog1.ShowDialog()
        source_path = OpenFileDialog1.FileName

       
        TextBox2.Text = System.IO.File.ReadAllText(source_path)
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        On Error Resume Next
        On Error Resume Next
        Dim keyword_path As String
  
        OpenFileDialog1.Title = "Select a KeyWords file:"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Arduino Library KeyWords files (*.txt)|*.txt|All files (*.*)|*.*"
        OpenFileDialog1.ShowDialog()
        keyword_path = OpenFileDialog1.FileName

        TextBox3.Text = System.IO.File.ReadAllText(keyword_path)
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        On Error Resume Next
        Dim exam_path As String
 
        OpenFileDialog1.Title = "Select a Example file:"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Arduino Library Example files (*.ino)|*.ino|PDE files (*.pde)|*.pde|All files (*.*)|*.*"
        OpenFileDialog1.ShowDialog()
        exam_path = OpenFileDialog1.FileName


        TextBox5.Text = System.IO.File.ReadAllText(exam_path)
    End Sub


    Private Sub Label5_Click_4(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        Shell("explorer.exe https://www.arduino.cc/en/Hacking/LibraryTutorial", vbNormalFocus)
    End Sub



    Private Function FindIt(ByRef Box As RichTextBox, ByVal Search As String, ByVal Color As Color, Optional ByVal Start As Int32 = 0) As Int32
        Dim retval As Int32      'Instr returns a long
        Dim Source As String 'variable used in Instr
        Try

            Source = Box.Text   'put the text to search into the variable

            retval = Source.IndexOf(Search, Start) 'do the first search,
            'starting at the beginning
            'of the text

            If retval <> -1 Then 'there is at least one more occurrence of
                'the string

                'the RichTextBox doesn't support multiple active selections, so
                'this section marks the occurrences of the search string by
                'making them Bold and Red

                With Box
                    .SelectionStart = retval
                    .SelectionLength = Search.Length
                    .SelectionColor = Color
                    .DeselectAll() 'this line removes the selection highlight
                End With

                Start = retval + Search.Length 'move the starting point past the
                'first occurrence

                'FindIt calls itself with new arguments
                'this is what makes it Recursive
                FindIt = 1 + FindIt(Box, Search, Color, Start)
            End If
        Catch ex As Exception
            Debug.WriteLine(ex.Message)
        End Try

        Return retval

    End Function
    

    Private Sub Button14_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        On Error Resume Next
        Dim tmp2 As String
        'search in internal keywords
        Dim current_position As Integer
        current_position = TextBox2.SelectionStart
        TextBox2.Select(0, TextBox2.TextLength)
        TextBox2.SelectionColor = Color.Black
        TextBox2.SelectionStart = current_position
        For i As Integer = 0 To ListBox1.Items.Count - 1
            tmp2 = ListBox1.Items.Item(i)

            FindIt(Me.TextBox2, tmp2, Color.Brown)

        Next
        TextBox2.SelectionStart = current_position
    End Sub

    Private Sub Button13_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        On Error Resume Next
        Dim tmp2 As String
        'search in internal keywords
        Dim current_position As Integer
        current_position = TextBox1.SelectionStart
        TextBox1.Select(0, TextBox1.TextLength)
        TextBox1.SelectionColor = Color.Black
        TextBox1.SelectionStart = current_position
        For i As Integer = 0 To ListBox1.Items.Count - 1
            tmp2 = ListBox1.Items.Item(i)

            FindIt(Me.TextBox1, tmp2, Color.Brown)

        Next
        TextBox1.SelectionStart = current_position
    End Sub

   

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        On Error Resume Next
        Dim tmp2 As String
        'search in internal keywords
        Dim current_position As Integer
        current_position = TextBox5.SelectionStart
        TextBox5.Select(0, TextBox5.TextLength)
        TextBox5.SelectionColor = Color.Black
        TextBox5.SelectionStart = current_position
        For i As Integer = 0 To ListBox1.Items.Count - 1
            tmp2 = ListBox1.Items.Item(i)

            FindIt(Me.TextBox5, tmp2, Color.DarkOrange)

        Next
        TextBox5.SelectionStart = current_position
    End Sub



    Private Sub Button12_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        TextBox3.SelectedText = Chr(9)
        TextBox3.Focus()
    End Sub
End Class
