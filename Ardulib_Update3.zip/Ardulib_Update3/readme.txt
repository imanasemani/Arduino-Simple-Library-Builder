You need :
Visual Basic 2010
windows installer 3.1
Microsoft Dot Net Framework 4.0


Iman Asemani
post.asemani@gmail.com