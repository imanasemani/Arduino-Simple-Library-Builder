﻿Public Class Form2

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Form1.Show()
        Me.Visible = False
        Timer1.Enabled = False
    End Sub
End Class